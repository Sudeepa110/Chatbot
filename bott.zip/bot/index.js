const { Client, GatewayIntentBits } = require('discord.js');
const { OpenAI } = require('openai');

const DiscordBotAPIKey = "MTMxODU3Mzg4NzM0NDIxODE0Mw.GM0f7v.wI3rjLZXqohW56FWlKVPPm_naQDFNG0cFP8LTU";
const OpenAIAPIKey = "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";

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent
    ]
});

const openai = new OpenAI({
    apiKey: OpenAIAPIKey
});

client.on('ready', () => {
    console.log(`Logged in as ${client.user.tag}!`);
});

client.on("messageCreate", async (msg) => {
    if (msg.author.bot) return;
    if (!msg.mentions.has(client.user)) return;

    const userInput = msg.content.replace(/<@\d+>/g, "").trim();

    let responseMessage = await msg.reply("Generating response...");

    try {
        const completion = await openai.chat.completions.create({
            model: "gpt-4o-mini", // Use the lightweight gpt-4o-mini model
            messages: [
                { role: "system", content: "You are an AI chatbot assistant." },
                { role: "user", content: userInput }
            ],
            max_tokens: 1000
        });

        const botResponse = completion.choices[0].message.content;
        responseMessage.edit(botResponse);
    } catch (error) {
        console.error("Error:", error.message);
        responseMessage.edit("An error occurred while generating the response.");
    }
});

client.login(DiscordBotAPIKey);
